import { MinPriorityQueue } from "./pq.js";
import { BitWriter, BitReader } from "./bitstream.js";

class Node {
  constructor(freq, value = null, left = null, right = null) {
    this.freq = freq;
    this.value = value; // 0..255 for leaf, null for internal
    this.left = left;
    this.right = right;
  }
  isLeaf() { return this.value !== null; }
}

function buildFrequencyTable(data) {
  const freq = new Uint32Array(256);
  for (let i = 0; i < data.length; i++) freq[data[i]] += 1;
  return freq;
}

function buildTree(freqTable) {
  const pq = new MinPriorityQueue((a, b) => {
    if (a.freq !== b.freq) return a.freq - b.freq;
    // tie-breaker: leaf nodes first, then by value
    const av = a.value === null ? 999 : a.value;
    const bv = b.value === null ? 999 : b.value;
    return av - bv;
  });

  for (let v = 0; v < 256; v++) {
    const f = freqTable[v];
    if (f > 0) pq.push(new Node(f, v, null, null));
  }

  // Edge case: empty input
  if (pq.size() === 0) return new Node(0, 0, null, null);

  // Edge case: one unique byte
  if (pq.size() === 1) {
    const only = pq.pop();
    return new Node(only.freq, null, only, new Node(0, 0, null, null));
  }

  while (pq.size() > 1) {
    const a = pq.pop();
    const b = pq.pop();
    pq.push(new Node(a.freq + b.freq, null, a, b));
  }
  return pq.pop();
}

function buildCodeMap(root) {
  const codes = new Array(256).fill(null);

  const dfs = (node, prefix) => {
    if (node.isLeaf()) {
      codes[node.value] = prefix.length === 0 ? "0" : prefix;
      return;
    }
    dfs(node.left, prefix + "0");
    dfs(node.right, prefix + "1");
  };

  dfs(root, "");
  return codes;
}

export function huffmanCompress(inputBytes) {
  const freq = buildFrequencyTable(inputBytes);
  const tree = buildTree(freq);
  const codes = buildCodeMap(tree);

  const bw = new BitWriter();
  for (let i = 0; i < inputBytes.length; i++) {
    bw.writeBitsFromString(codes[inputBytes[i]]);
  }
  const payload = bw.finish();

  return {
    payload,
    freqTable: freq,
    originalSize: inputBytes.length
  };
}

export function huffmanDecompress(payloadBytes, freqTable, originalSize) {
  const tree = buildTree(freqTable);

  const out = new Uint8Array(originalSize);
  const br = new BitReader(payloadBytes);

  let node = tree;
  let produced = 0;

  while (produced < originalSize) {
    const bit = br.readBit();
    if (bit === null) {
      throw new Error("Unexpected end of bitstream while decoding.");
    }
    node = bit === 0 ? node.left : node.right;
    if (node.isLeaf()) {
      out[produced] = node.value;
      produced += 1;
      node = tree;
    }
  }
  return out;
}
