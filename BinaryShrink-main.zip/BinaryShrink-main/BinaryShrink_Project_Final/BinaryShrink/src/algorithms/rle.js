export function rleCompress(inputBytes) {
  const out = [];
  if (inputBytes.length === 0) return { payload: new Uint8Array(), originalSize: 0 };

  let runVal = inputBytes[0];
  let runLen = 1;

  for (let i = 1; i < inputBytes.length; i++) {
    const v = inputBytes[i];
    if (v === runVal && runLen < 255) {
      runLen += 1;
    } else {
      out.push(runLen, runVal);
      runVal = v;
      runLen = 1;
    }
  }
  out.push(runLen, runVal);

  return { payload: Uint8Array.from(out), originalSize: inputBytes.length };
}

export function rleDecompress(payloadBytes, originalSize) {
  const out = new Uint8Array(originalSize);
  let outIdx = 0;

  for (let i = 0; i + 1 < payloadBytes.length; i += 2) {
    const count = payloadBytes[i];
    const value = payloadBytes[i + 1];
    for (let k = 0; k < count; k++) {
      if (outIdx >= originalSize) {
        throw new Error("RLE payload expands beyond expected original size.");
      }
      out[outIdx++] = value;
    }
  }

  if (outIdx !== originalSize) {
    throw new Error("RLE payload ended early (size mismatch).");
  }

  return out;
}
