export class BitWriter {
  constructor() {
    this.bytes = [];
    this.current = 0;
    this.bitPos = 0; // 0..7 (LSB first inside current)
  }

  writeBit(bit) {
    if (bit) this.current |= (1 << this.bitPos);
    this.bitPos += 1;
    if (this.bitPos === 8) {
      this.bytes.push(this.current);
      this.current = 0;
      this.bitPos = 0;
    }
  }

  writeBitsFromString(bitString) {
    for (let i = 0; i < bitString.length; i++) {
      const c = bitString.charCodeAt(i);
      this.writeBit(c === 49); // '1'
    }
  }

  finish() {
    if (this.bitPos !== 0) {
      this.bytes.push(this.current);
      this.current = 0;
      this.bitPos = 0;
    }
    return Uint8Array.from(this.bytes);
  }
}

export class BitReader {
  constructor(uint8) {
    this.data = uint8;
    this.byteIndex = 0;
    this.bitPos = 0;
  }

  readBit() {
    if (this.byteIndex >= this.data.length) return null;
    const b = this.data[this.byteIndex];
    const bit = (b >> this.bitPos) & 1;
    this.bitPos += 1;
    if (this.bitPos === 8) {
      this.bitPos = 0;
      this.byteIndex += 1;
    }
    return bit;
  }
}
