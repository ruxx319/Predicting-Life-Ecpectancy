import { Algo, buildContainer, parseContainer } from "./fileformat.js";
import { rleCompress, rleDecompress } from "./algorithms/rle.js";
import { huffmanCompress, huffmanDecompress } from "./algorithms/huffman.js";

const el = (id) => document.getElementById(id);

const dropzone = el("dropzone");
const fileInput = el("fileInput");
const mode = el("mode");
const algo = el("algo");
const runBtn = el("runBtn");
const resetBtn = el("resetBtn");
const statusEl = el("status");

const metrics = el("metrics");
const mIn = el("mIn");
const mOut = el("mOut");
const mRatio = el("mRatio");

const downloadWrap = el("download");
const downloadLink = el("downloadLink");

let selectedFile = null;

function fmtBytes(n) {
  if (n < 1024) return `${n} B`;
  const kb = n / 1024;
  if (kb < 1024) return `${kb.toFixed(2)} KB`;
  const mb = kb / 1024;
  return `${mb.toFixed(2)} MB`;
}

function setStatus(msg, isError = false) {
  statusEl.textContent = msg;
  statusEl.style.color = isError ? "var(--danger)" : "var(--muted)";
}

function setResultMetrics(inputSize, outputSize) {
  metrics.hidden = false;
  mIn.textContent = fmtBytes(inputSize);
  mOut.textContent = fmtBytes(outputSize);

  if (inputSize === 0) {
    mRatio.textContent = "-";
  } else {
    const ratio = (outputSize / inputSize) * 100;
    mRatio.textContent = `${ratio.toFixed(2)}%`;
  }
}

function hideDownload() {
  downloadWrap.hidden = true;
  downloadLink.removeAttribute("href");
}

function showDownload(blob, filename) {
  const url = URL.createObjectURL(blob);
  downloadLink.href = url;
  downloadLink.download = filename;
  downloadWrap.hidden = false;

  // Make it obvious something happened:
  downloadWrap.scrollIntoView({ behavior: "smooth", block: "nearest" });

  // Try to auto-trigger the download (browsers may block this, so link remains visible).
  try {
    setTimeout(() => downloadLink.click(), 0);
  } catch (_) {}
}

function resetUI() {
  selectedFile = null;
  fileInput.value = "";
  runBtn.disabled = true;
  metrics.hidden = true;
  hideDownload();
  setStatus("Choose a file to begin.");
}

async function readFileAsUint8(file) {
  const buf = await file.arrayBuffer();
  return new Uint8Array(buf);
}

function suggestOutputName(inputName, modeValue) {
  if (modeValue === "compress") return `${inputName}.bzc`;
  // for decompress: we restore original name from header, but fallback:
  return inputName.replace(/\.bzc$/i, "") || "output.bin";
}

dropzone.addEventListener("click", () => fileInput.click());

dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("drag");
});
dropzone.addEventListener("dragleave", () => dropzone.classList.remove("drag"));
dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("drag");
  const f = e.dataTransfer.files?.[0];
  if (f) onFileSelected(f);
});

fileInput.addEventListener("change", (e) => {
  const f = e.target.files?.[0];
  if (f) onFileSelected(f);
});

mode.addEventListener("change", () => {
  hideDownload();
  metrics.hidden = true;
  setStatus("Ready. Click Run.");
});

resetBtn.addEventListener("click", resetUI);

function onFileSelected(file) {
  selectedFile = file;
  runBtn.disabled = false;
  hideDownload();
  metrics.hidden = true;
  setStatus(`Selected: ${file.name} (${fmtBytes(file.size)})`);
}

runBtn.addEventListener("click", async () => {
  if (!selectedFile) return;

  runBtn.disabled = true;
  hideDownload();
  metrics.hidden = true;

  try {
    if (mode.value === "compress") {
      await handleCompress(selectedFile);
    } else {
      await handleDecompress(selectedFile);
    }
  } catch (err) {
    setStatus(err?.message ? `Error: ${err.message}` : "Unknown error", true);
    console.error(err);
  } finally {
    runBtn.disabled = false;
  }
});

async function handleCompress(file) {
  setStatus("Reading file...");
  const inputBytes = await readFileAsUint8(file);

  setStatus("Compressing...");
  const chosen = algo.value;

  let algoId;
  let payloadBytes;
  let freqTable = null;

  if (chosen === "rle") {
    algoId = Algo.RLE;
    const res = rleCompress(inputBytes);
    payloadBytes = res.payload;
  } else {
    algoId = Algo.HUFFMAN;
    const res = huffmanCompress(inputBytes);
    payloadBytes = res.payload;
    freqTable = res.freqTable;
  }

  const containerBytes = buildContainer({
    algoId,
    filename: file.name,
    originalSize: inputBytes.length,
    payloadBytes,
    freqTable
  });

  const outName = suggestOutputName(file.name, "compress");
  const blob = new Blob([containerBytes], { type: "application/octet-stream" });

  setResultMetrics(inputBytes.length, containerBytes.length);
  showDownload(blob, outName);
  setStatus("Done. Download your compressed file.");
}

async function handleDecompress(file) {
  setStatus("Reading file...");
  const containerBytes = await readFileAsUint8(file);

  setStatus("Parsing container...");
  const parsed = parseContainer(containerBytes);

  setStatus("Decompressing...");
  let outputBytes;

  if (parsed.algoId === Algo.RLE) {
    outputBytes = rleDecompress(parsed.payloadBytes, parsed.originalSize);
  } else if (parsed.algoId === Algo.HUFFMAN) {
    outputBytes = huffmanDecompress(parsed.payloadBytes, parsed.freqTable, parsed.originalSize);
  } else {
    throw new Error("Unsupported algorithm id in container.");
  }

  const blob = new Blob([outputBytes], { type: "application/octet-stream" });
  const outName = parsed.filename || suggestOutputName(file.name, "decompress");

  setResultMetrics(containerBytes.length, outputBytes.length);
  showDownload(blob, outName);
  setStatus("Done. Download your decompressed file.");
}

resetUI();
