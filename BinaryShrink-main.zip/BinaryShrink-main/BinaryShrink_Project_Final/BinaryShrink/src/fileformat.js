const MAGIC = [0x42, 0x5A, 0x43, 0x31]; // 'BZC1'
export const Algo = Object.freeze({
  HUFFMAN: 1,
  RLE: 2
});

function utf8Encode(str) {
  return new TextEncoder().encode(str);
}
function utf8Decode(bytes) {
  return new TextDecoder().decode(bytes);
}

export function buildContainer({ algoId, filename, originalSize, payloadBytes, freqTable = null }) {
  const nameBytes = utf8Encode(filename);
  if (nameBytes.length > 65535) throw new Error("Filename too long.");

  const hasFreq = algoId === Algo.HUFFMAN;
  const freqLen = hasFreq ? 256 * 4 : 0;

  const headerLen = 4 + 1 + 2 + nameBytes.length + 4 + freqLen;
  const totalLen = headerLen + payloadBytes.length;

  const out = new Uint8Array(totalLen);
  let o = 0;

  out.set(MAGIC, o); o += 4;
  out[o++] = algoId;

  // uint16 filename length
  out[o++] = nameBytes.length & 0xFF;
  out[o++] = (nameBytes.length >> 8) & 0xFF;

  out.set(nameBytes, o); o += nameBytes.length;

  // uint32 original size (little-endian)
  out[o++] = (originalSize >>> 0) & 0xFF;
  out[o++] = (originalSize >>> 8) & 0xFF;
  out[o++] = (originalSize >>> 16) & 0xFF;
  out[o++] = (originalSize >>> 24) & 0xFF;

  if (hasFreq) {
    if (!freqTable || freqTable.length !== 256) throw new Error("Missing/invalid frequency table.");
    const dv = new DataView(out.buffer);
    for (let i = 0; i < 256; i++) {
      dv.setUint32(o + i * 4, freqTable[i], true);
    }
    o += 256 * 4;
  }

  out.set(payloadBytes, o);
  return out;
}

export function parseContainer(containerBytes) {
  if (containerBytes.length < 4 + 1 + 2 + 4) throw new Error("File too small.");

  let o = 0;
  for (let i = 0; i < 4; i++) {
    if (containerBytes[o + i] !== MAGIC[i]) throw new Error("Not a BinaryShrink .bzc file (bad magic).");
  }
  o += 4;

  const algoId = containerBytes[o++];

  const nameLen = containerBytes[o] | (containerBytes[o + 1] << 8);
  o += 2;

  if (containerBytes.length < o + nameLen + 4) throw new Error("Corrupted header (filename).");
  const nameBytes = containerBytes.slice(o, o + nameLen);
  const filename = utf8Decode(nameBytes);
  o += nameLen;

  const originalSize =
    (containerBytes[o]      ) |
    (containerBytes[o + 1] << 8) |
    (containerBytes[o + 2] << 16) |
    (containerBytes[o + 3] << 24) >>> 0;
  o += 4;

  let freqTable = null;
  if (algoId === Algo.HUFFMAN) {
    const need = 256 * 4;
    if (containerBytes.length < o + need) throw new Error("Corrupted header (frequency table).");
    freqTable = new Uint32Array(256);
    const dv = new DataView(containerBytes.buffer, containerBytes.byteOffset, containerBytes.byteLength);
    for (let i = 0; i < 256; i++) {
      freqTable[i] = dv.getUint32(o + i * 4, true);
    }
    o += need;
  }

  const payloadBytes = containerBytes.slice(o);

  return { algoId, filename, originalSize, freqTable, payloadBytes };
}
