import { rleCompress, rleDecompress } from "../src/algorithms/rle.js";
import { huffmanCompress, huffmanDecompress } from "../src/algorithms/huffman.js";
import { Algo, buildContainer, parseContainer } from "../src/fileformat.js";

function assert(cond, msg) {
  if (!cond) throw new Error(msg || "Assertion failed");
}

function bytesEqual(a, b) {
  if (a.length !== b.length) return false;
  for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
  return true;
}

function randomBytes(n, seed = 1234) {
  // deterministic xorshift32
  let x = seed >>> 0;
  const out = new Uint8Array(n);
  for (let i = 0; i < n; i++) {
    x ^= x << 13; x >>>= 0;
    x ^= x >> 17; x >>>= 0;
    x ^= x << 5;  x >>>= 0;
    out[i] = x & 0xFF;
  }
  return out;
}

function testRLE() {
  const inputs = [
    new Uint8Array([]),
    new Uint8Array([1,1,1,1,1]),
    new Uint8Array([1,2,3,4,5,6,7]),
    Uint8Array.from({length: 600}, (_, i) => (i % 2 === 0 ? 9 : 9)), // long runs
    randomBytes(2048)
  ];

  for (const inp of inputs) {
    const c = rleCompress(inp);
    const d = rleDecompress(c.payload, inp.length);
    assert(bytesEqual(inp, d), "RLE roundtrip failed");
  }
  console.log("RLE tests: OK");
}

function testHuffman() {
  const inputs = [
    new Uint8Array([]),
    new TextEncoder().encode("aaaaabbbbccccccddddddddd"),
    new TextEncoder().encode("Operating Systems: file IO, buffering, and compression!"),
    randomBytes(4096)
  ];

  for (const inp of inputs) {
    const c = huffmanCompress(inp);
    const d = huffmanDecompress(c.payload, c.freqTable, inp.length);
    assert(bytesEqual(inp, d), "Huffman roundtrip failed");
  }
  console.log("Huffman tests: OK");
}

function testContainer() {
  const inp = new TextEncoder().encode("hello hello hello hello");
  const h = huffmanCompress(inp);

  const container = buildContainer({
    algoId: Algo.HUFFMAN,
    filename: "demo.txt",
    originalSize: inp.length,
    payloadBytes: h.payload,
    freqTable: h.freqTable
  });

  const parsed = parseContainer(container);
  assert(parsed.filename === "demo.txt", "Container filename mismatch");
  assert(parsed.algoId === Algo.HUFFMAN, "Container algo mismatch");

  const out = huffmanDecompress(parsed.payloadBytes, parsed.freqTable, parsed.originalSize);
  assert(bytesEqual(inp, out), "Container roundtrip failed");

  console.log("Container tests: OK");
}

testRLE();
testHuffman();
testContainer();
console.log("All tests passed.");
