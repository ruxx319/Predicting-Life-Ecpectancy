# STAR Report: BinaryShrink (File Compression Tool)

## Situation
While building a browser-based compression tool, the main challenge was making the compressed output **portable and correct**.
If the app only produced raw compressed bytes, decompression would fail later because the decoder needs extra metadata:
the original file name, original size, and for Huffman the exact frequency table used to rebuild the same coding tree.

Another challenge was handling data as **binary bytes**, not just text. Some sample projects only work for `.txt`, but the
assignment expects general file handling and correct I/O behavior.

## Task
I needed to create a **lossless** compression and decompression tool that:
- compresses any file in the browser
- saves an output file in a custom format
- decompresses the output back to the exact original bytes
- is valid and runnable as a static GitHub Pages project

## Action
To solve portability and correctness, I designed a simple binary container format (`.bzc`):
- a fixed magic signature so the app can validate inputs
- algorithm id to decide which decoder to use
- the original file name so the decompressed output keeps its name
- the original size to stop decoding at the correct point
- for Huffman, a 256-entry frequency table stored in the header so decoding can rebuild the same Huffman tree

For algorithm correctness:
- implemented RLE as (count, value) pairs with strict size checks
- implemented Huffman with a frequency table, tree construction via a priority queue, and bit-level payload packing
- added Node-based tests that validate roundtrip correctness for random binary data and text cases

For OS learning outcomes:
- worked with byte buffers, binary file headers, and predictable decoding
- thought about I/O overhead (header size vs compression gains)
- handled error cases (bad magic, truncated payload, size mismatches)

## Result
The final project runs as a static website and can compress and decompress files without data loss.
The `.bzc` output is self-contained so decompression works even after closing and reopening the site.

The included tests confirm that:
- RLE and Huffman both roundtrip correctly
- the container format stores enough metadata to decode successfully

Date: 2025-12-26
